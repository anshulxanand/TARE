/** @file hal/micro/cortexm3/mpu.h
 *
 * <!--(C) COPYRIGHT 2010 STMicroelectronics. All rights reserved.        -->
 */


#ifndef MPU_H_
#define MPU_H_

#define BYPASS_MPU(blah) blah

#endif//MPU_H_
