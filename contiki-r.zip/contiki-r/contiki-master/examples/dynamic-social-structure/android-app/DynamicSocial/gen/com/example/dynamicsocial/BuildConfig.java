/** Automatically generated file. DO NOT MODIFY */
package com.example.dynamicsocial;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}